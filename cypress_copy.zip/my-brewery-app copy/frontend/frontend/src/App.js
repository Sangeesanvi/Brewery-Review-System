import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import './App.css';
import { Login } from './login';
import { Register } from './Register';
import { Dashboard } from './Dashboard';
import { BreweryDetail } from './BreweryDetail';

function App() {
    const [currentForm, setCurrentForm] = useState('login');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userName, setUserName] = useState('');

    const toggleForm = (formName) => {
        setCurrentForm(formName);
    };

    const handleLoginSuccess = (user) => {
        setIsLoggedIn(true);
        setUserName(user.name); // Assuming 'user' object contains 'name'
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setCurrentForm('login');
    };

    return (
        <Router>
            <div className="App">
                {isLoggedIn ? (
                    <Routes>
                        <Route path="/" element={<Dashboard userName={userName} onLogout={handleLogout} />} />
                        <Route path="/brewery/:id" element={<BreweryDetail />} />
                    </Routes>
                ) : (
                    <Routes>
                        <Route path="/" element={currentForm === 'login' ? <Login onFormSwitch={toggleForm} onLoginSuccess={handleLoginSuccess} /> : <Register onFormSwitch={toggleForm} />} />
                        <Route path="*" element={<Navigate to="/" />} />
                    </Routes>
                )}
            </div>
        </Router>
    );
}

export default App;
