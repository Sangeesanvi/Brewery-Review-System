import React, { useState, useEffect } from 'react';
import './Dashboard.css';
import { useNavigate } from 'react-router-dom';

export const Dashboard = ({ userName, onLogout }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [breweries, setBreweries] = useState([]);
    const [filteredBreweries, setFilteredBreweries] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchBreweries();
    }, []);

    const fetchBreweries = async () => {
        try {
            const response = await fetch('https://api.openbrewerydb.org/v1/breweries');
            const data = await response.json();
        
            const breweryIds = data.map(item => item.id)
            const response1 = await fetch(`http://localhost:5000/ratings/latsetRatings/[${breweryIds}]`)
            console.log('ids', response1, breweryIds)

            for(let ind = 0 ; ind < data.length ; ind++){
                const breweriesRatingResponse = await fetch(`http://localhost:5000/ratings/[${data[ind].id}]/ratings`)
                const breweriesRatingsData = await breweriesRatingResponse.json()
                data[ind].ratings = breweriesRatingsData
            }

            setBreweries(data);
            setFilteredBreweries(data);
        } catch (error) {
            console.error('Error fetching breweries:', error);
        }
    };

    const handleSearch = (e) => {
        const query = e.target.value.toLowerCase();
        const filteredBreweries = breweries.filter(brewery =>
            brewery.name.toLowerCase().includes(query) ||
            brewery.city.toLowerCase().includes(query) ||
            brewery.id.toLowerCase().includes(query) ||
            brewery.state.toLowerCase().includes(query) ||
            (brewery.brewery_type && brewery.brewery_type.toLowerCase().includes(query)) || // Filter by type
            (brewery.phone && brewery.phone.toString().includes(query)) // Filter by phone number
        );
        setSearchQuery(query);
        setFilteredBreweries(filteredBreweries);
    };

    const handleBreweryClick = (id) => {
        navigate(`/brewery/${id}`);
    };

    const calculateAverageRating = (ratings) => {
        if (!ratings || ratings.length === 0) return 2;
        const totalRating = ratings.reduce((acc, rating) => acc + rating.value, 0);
        return Math.round(totalRating / ratings.length);
    };

    return (
        <div className="dashboard-container">
            <header className="dashboard-header">
                <div className="header-left">
                    <h1>Brewery Review System</h1>
                </div>
                <div className="header-right">
                    <span>{userName}</span>
                    <button className="logout-button" onClick={onLogout}>Logout</button>
                </div>
            </header>
            <main>
                <div className="search-container">
                    <input
                        type="text"
                        placeholder="Search breweries by name, city, ID, or state..."
                        value={searchQuery}
                        onChange={handleSearch}
                    />
                </div>
                <div className="breweries-container">
                    {filteredBreweries.map((brewery, index) => (
                        <div key={index} className="brewery-card" onClick={() => handleBreweryClick(brewery.id)}>
                            <h2>{brewery.name}</h2>
                            <p>{brewery.city}, {brewery.state}</p>
                            <p>Address: {brewery.street}</p>
                            <p>Phone: {brewery.phone}</p>
                            <p>
                                Website: <a href={brewery.website_url} target="_blank" rel="noopener noreferrer">{brewery.website_url}</a>
                            </p>
                            <p>Rating: {calculateAverageRating(brewery.ratings)}</p>
                            <hr />
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};
