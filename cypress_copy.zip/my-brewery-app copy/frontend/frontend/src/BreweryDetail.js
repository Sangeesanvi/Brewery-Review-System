import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './BreweryDetail.css';

export const BreweryDetail = () => {
    const { id } = useParams();
    const [brewery, setBrewery] = useState(null);
    const [newRating, setNewRating] = useState('');
    const [isRatingSubmitted, setIsRatingSubmitted] = useState(false);
    const [ratings, setRatings] = useState([]);

    useEffect(() => {
        const fetchBreweryDetail = async () => {
            try {
                const breweryResponse = await fetch(`https://api.openbrewerydb.org/v1/breweries/${id}`);
                const breweryData = await breweryResponse.json();
                setBrewery(breweryData);

                const ratingsResponse = await fetch(`http://localhost:5000/ratings/${id}/ratings`);
                const ratingsData = await ratingsResponse.json();
                setRatings(ratingsData);
            } catch (error) {
                console.error('Error fetching brewery details:', error);
            }
        };
        
        fetchBreweryDetail();
    }, [id, isRatingSubmitted]);

    const handleSubmitRating = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:5000/ratings/${id}/ratings`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    value: newRating,
                }),
            });
            if (response.ok) {
                setNewRating('');
                setIsRatingSubmitted(true);
                alert('Rating submitted successfully');  // Show alert on successful submission
                setIsRatingSubmitted(false);
            } else {
                console.error('Failed to submit rating:', response.statusText);
            }
        } catch (error) {
            console.error('Error submitting rating:', error);
        }
    };

    if (!brewery) return <div>Loading...</div>;

    return (
        <div className="brewery-detail-container">
            <h2>{brewery.name}</h2>
            <p><strong>Brewery ID:</strong> {brewery.id}</p>
            <p><strong>Type:</strong> {brewery.brewery_type}</p>
            <p><strong>Address 1:</strong> {brewery.street}</p>
            <p><strong>Address 2:</strong> {brewery.address_2 || 'N/A'}</p>
            <p><strong>Address 3:</strong> {brewery.address_3 || 'N/A'}</p>
            <p><strong>City:</strong> {brewery.city}</p>
            <p><strong>State/Province:</strong> {brewery.state}</p>
            <p><strong>Postal Code:</strong> {brewery.postal_code}</p>
            <p><strong>Country:</strong> {brewery.country}</p>
            <p><strong>Longitude:</strong> {brewery.longitude}</p>
            <p><strong>Latitude:</strong> {brewery.latitude}</p>
            <p><strong>Phone:</strong> {brewery.phone}</p>
            <p>
                <strong>Website:</strong> <a href={brewery.website_url} target="_blank" rel="noopener noreferrer">{brewery.website_url}</a>
            </p>
            <div className="rating-form">
                <form onSubmit={handleSubmitRating}>
                    <label htmlFor="rating">Rate this brewery (1-5):</label>
                    <input
                        type="number"
                        id="rating"
                        min="1"
                        max="5"
                        name="rating"
                        value={newRating}
                        onChange={(e) => setNewRating(e.target.value)}
                        required
                    />
                    <button type="submit">Submit Rating</button>
                </form>
                {/* {ratings.length > 0 && (
                    <div>
                        <h3>Ratings:</h3>
                        <ul>
                            {ratings.map((rating, index) => (
                                <li key={index}>Rating: {rating.value}</li>
                            ))}
                        </ul>
                    </div>
                )} */}
            </div>
        </div>
    );
};
